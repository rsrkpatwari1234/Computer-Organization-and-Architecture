#include <CL/sycl.hpp>
int main() {
    std::cout << "Hello world! \n" << std::endl;
}
